﻿namespace CustomRandomList
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            RandomList rndL = new RandomList();
        }
    }
}
