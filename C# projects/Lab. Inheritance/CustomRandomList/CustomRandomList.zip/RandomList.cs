﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private List<string> list;

        public string RandomString()
        {
            Random rnd = new Random();
            int elementToRemove = rnd.Next(0, list.Count);
            string elementToReturn = list[elementToRemove];
            list.Remove(list[elementToRemove]);
            return elementToReturn;
        }
    }
}
