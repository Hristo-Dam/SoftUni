﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace CarManufacturer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car vehicle1 = new Car();
            vehicle1.Make = "VW";
            vehicle1.Model = "MK3";
            vehicle1.Year = 1992;

            Console.WriteLine($"Make: {vehicle1.Make}\nModel: {vehicle1.Model}\nYear: {vehicle1.Year}");
        }
    }
}
