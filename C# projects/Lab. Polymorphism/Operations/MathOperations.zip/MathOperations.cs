﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operations
{
    public class MathOperations
    {
        public int Add(int a, int b)
        {
            int result = 0;
            return result;
        }
        public double Add(double a, double b, double c)
        {
            double result = 0;
            return result;
        }
        public decimal Add(decimal a, decimal b, decimal c)
        {
            decimal result = 0;
            return result;
        }
    }
}
