﻿namespace ImplementLinkedList
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            LinkedList<object> list = new LinkedList<object>();
            
        }
    }
}