﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplementLinkedList
{
    public class CustomLinkedList
    {
        private class Node
        {
            private object element;
            private Node next;
            public object Element
            {
                get { return element; }
                set { element = value; }
            }
            public Node Next
            {
                get { return next; }
                set { next = value; }
            }
            public Node(object element, Node prevNode)
            {
            }
            public Node(object element)
            {
            }
        }

        private Node head;
        private Node tail;
        private int count;
        public CustomLinkedList()
        {
            this.head = null;
            this.tail = null;
            this.count = 0;
        }
        public void Add(object item)
        {
            Node newNode = new Node(item);

            if (head == null)
            {
                head = newNode;
                tail = newNode;
            }
            else
            {
                this.tail.Element = item;
                this.tail.Next = tail;
            }

            count++;
        }
        //public object Remove(int index)
        //{
        //}
        //public int RemoveAt(object item)
        //{
        //}
        //public int IndexOf(object item)
        //{
        //}
        //public bool Contains(object item)
        //{
        //}
        //public object this[int index]
        //{
        //}
        public int Count
        {
            get { return count; }
            private set { count = value; }
        }
    }
}
