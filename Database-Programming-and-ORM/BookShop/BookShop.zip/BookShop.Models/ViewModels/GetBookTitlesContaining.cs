﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Models.ViewModels
{
    public class GetBookTitlesContaining
    {
        public string Title { get; set; }
    }
}
