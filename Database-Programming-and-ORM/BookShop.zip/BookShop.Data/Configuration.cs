﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=DESKTOP-HNCTHM8;Database=BookShop-Complete;Integrated Security=True;";
    }
}
