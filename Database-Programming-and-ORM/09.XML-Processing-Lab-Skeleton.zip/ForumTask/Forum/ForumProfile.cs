﻿
namespace Forum
{
    public class ForumProfile
    {
        //TODO...
    }
}
