﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Employees
{
    public class StartUp
    {
        static void Main()
        {

        }
    }
}
