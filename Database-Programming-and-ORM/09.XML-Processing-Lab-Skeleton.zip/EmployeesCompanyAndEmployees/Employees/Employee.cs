﻿using System.Xml.Serialization;

namespace Employees
{
    public class Employee
    {
        public int Id { get; set; }

        public string EmployeeName { get; set; }

        public string DepartmentName { get; set; }
    }
}
