﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace CompanyAndEmployees
{
   public class Employee
    {
        public string Name { get; set; }

        public string Age { get; set; }
    }
}
