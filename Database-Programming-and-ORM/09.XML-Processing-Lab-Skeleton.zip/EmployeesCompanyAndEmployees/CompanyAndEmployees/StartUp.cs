﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using CompanyAndEmployees;

namespace CompanyAndEmployees
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
