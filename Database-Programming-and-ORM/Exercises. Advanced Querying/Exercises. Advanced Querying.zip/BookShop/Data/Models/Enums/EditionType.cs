﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShop.Data.Models.Enums
{
    public enum EditionType
    {
        Normal = 0,
        Promo = 1,
        Gold = 2
    }
}
