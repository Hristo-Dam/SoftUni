﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace BookShop.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Diablo;Integrated Security = True;";
    }
}
