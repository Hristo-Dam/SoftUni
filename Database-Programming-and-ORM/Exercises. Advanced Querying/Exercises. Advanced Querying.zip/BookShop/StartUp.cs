﻿namespace BookShop
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
