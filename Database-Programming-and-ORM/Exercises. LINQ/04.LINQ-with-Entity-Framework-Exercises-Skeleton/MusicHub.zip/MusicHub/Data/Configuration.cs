﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=MusicHub;Trusted_Connection=True;TrustServerCertificate=True;";
    }
}
