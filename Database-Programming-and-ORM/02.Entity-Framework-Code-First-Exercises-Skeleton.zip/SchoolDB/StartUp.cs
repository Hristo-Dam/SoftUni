﻿using SchoolDB.Data;
using SchoolDB.Models;

namespace SchoolDB
{
   public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
