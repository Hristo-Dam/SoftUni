﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SoftUni.Data;

namespace SoftUni
{
    public class StartUp
    {
        static void Main()
        {
            var context = new SoftUniContext();

        }

        public static string FindTownsStartingWith(SoftUniContext context, string letter)
        {

        }
        public static string EmployeeWithProjects(SoftUniContext context, int employeeId)
        {
           
        }

    }
}
