﻿
namespace Forum
{
    public class ForumProfile
    {
       
    }
}
