﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Forum.Models.ViewModels
{
    public class PostViewModel
    {
        public string PostContent { get; set; }
        public string User { get; set; }
    }
}
