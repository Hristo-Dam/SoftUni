﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Forum.DTO
{
    public class UsersImportModel
    {
        public string UserName { get; set; }
    }
}
