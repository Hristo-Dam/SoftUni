﻿namespace AsynchronousChronometer
{
    public class StartUp
    {
        public static void Main()
        {
            Chronometer chronometer = new Chronometer();

            // TODO: Write the console manipulation logic here...
        }
    }
}
