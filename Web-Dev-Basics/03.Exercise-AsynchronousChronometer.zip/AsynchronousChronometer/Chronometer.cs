﻿namespace AsynchronousChronometer
{
    using AsynchronousChronometer.Contracts;
    using System.Diagnostics;

    public class Chronometer : IChronometer
    {
        private Stopwatch _stopwatch;
        private List<string> _laps;

        public Chronometer()
        {
            _stopwatch = new Stopwatch();
            _laps = new List<string>();
        }

        // TODO: Implement IChronometer interface...

        // HINT for GetTime property:
        // Use the Elapsed property of the Stopwatch class to get the total elapsed time.
        // This property returns the time as a TimeSpan, so you should convert it to string in the correct format
        // You can format the string as expected in the exercise using this: @"mm\:ss\.ffff"
        public string GetTime => throw new NotImplementedException();

        public List<string> Laps => throw new NotImplementedException();

        public string Lap()
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        public void Start()
        {
            throw new NotImplementedException();
        }

        public void Stop()
        {
            throw new NotImplementedException();
        }
    }
}
// ®2025 Martin Yanev @ SoftUni BUDITEL