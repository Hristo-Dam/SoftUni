function signCheck(numOne, numTwo, numThree){
    let count = 0;
    if (numOne > 0){
        count++;
    }
    else if (numTwo > 0){
        count++;
    }
    else if (numThree > 0){
        count++
    }
    
    if (count % 2 != 0){
        console.log('Negative')
    }
    else{
        console.log('Positive')
    }
}
