function addItem() {
    let input = document.getElementById('newItemText');

    // TODO...

}