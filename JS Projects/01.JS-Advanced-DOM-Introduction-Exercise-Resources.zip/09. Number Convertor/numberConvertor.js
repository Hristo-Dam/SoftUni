function solve() {

    //TODO...
}