function generateReport() {
    //TODO
}