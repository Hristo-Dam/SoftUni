function sumTable() {
    //TODO

}